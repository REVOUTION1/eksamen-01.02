﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary2vb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2vb.Tests
{
    [TestClass()]
    public class PasswordCheckerTests
    {
        [TestMethod()]
        public void Check_85ymbols_ReturnsTrue()
        {
            //Arrange.
            string password = "ASqw12$$";
            bool expected = true;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
           Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_45ymbols_Returnsfalse()
        {
            //Arrange.
            string password = "Aq1$";

            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.IsFalse( actual);
        }

        [TestMethod()]
        public void Check_30ymbols_Returnsfalse()
        {
            //Arrange.
            string password = "ASDqwe123$ASDqwe123$ASDqwe123$";
            bool expected = false;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordwithDigits_ReturnsTrue()
        {
            //Arrange.
            string password = "ASDqwe1$";
            bool expected = true;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithoutDigits_Returnsfalse()
        {
            //Arrange.
            string password = "ASDqweASD$";
            bool expected = false;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithSpecSymbols_ReturnsTrue()
        {
            //Arrange.
            string password = "Aqwe123$";
            bool expected = true;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithoutSpecSymbols_ReturnsFalse()
        {
            //Arrange.
            string password = "ASDqwe123";
            bool expected = false;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithCapsSymbols_ReturnsTrue()
        {
            //Arrange.
            string password = "Aqwe123$";
            bool expected = true;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithoutCapsSymbols_ReturnsFalse()
        {
            //Arrange.
            string password = "asdqwe123$";
            bool expected = false;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithLowerSymbols_ReturnsTrue()
        {
            //Arrange.
            string password = "ASDq123$";
            bool expected = true;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordwithoutLowerSymbols_ReturnsFalse()
        {
            //Arrange.
            string password = "ASDQWE123$";
            bool expected = false;
            //Act.
            bool actual = PasswordChecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
    }
}
 